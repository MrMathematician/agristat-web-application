// Smooth scrolling to sections
        function scrollToSection(sectionId) {
            document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
        }

        // Dialog box for "More Control" button
        const infoDialog = document.getElementById('info-dialog');
        const openDialogBtn = document.getElementById('open-more-control');
        const closeDialogBtn = document.getElementById('close-dialog');

        openDialogBtn.addEventListener('click', () => {
            infoDialog.showModal();
        });

        closeDialogBtn.addEventListener('click', () => {
            infoDialog.close();
        });
   
